package com.infosys.financial;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/segment") public class SegmentationController { @PostMapping public Map<String,Object> endpoint(@RequestBody Map<String,Object> a){public Map<String,Object> segment(@RequestBody Map<String,Object> a){double v=Double.parseDouble(String.valueOf(a.getOrDefault("assetValue",0))); String tier=v>=10000000?"SPWS":v>=1000000?"SPCS/PINN":v>=250000?"PLAT":v>=100000?"GOLD":"PREF"; return Map.of("newTier",tier,"assetValue",v);}} }
