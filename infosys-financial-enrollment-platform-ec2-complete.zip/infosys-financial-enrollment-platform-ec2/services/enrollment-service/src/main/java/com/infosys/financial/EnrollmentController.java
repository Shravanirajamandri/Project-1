package com.infosys.financial;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/enrollments") public class EnrollmentController {
 private final EnrollmentRepository repo; public EnrollmentController(EnrollmentRepository repo){this.repo=repo;}
 @PostMapping public Map<String,Object> enroll(@RequestBody Map<String,Object> a){Enrollment e=new Enrollment(); e.processingId=String.valueOf(a.getOrDefault("processingId","PROC-MANUAL"));e.customerId=String.valueOf(a.getOrDefault("customerId","UNKNOWN"));e.accountId=String.valueOf(a.getOrDefault("accountId","UNKNOWN"));e.currentTier=String.valueOf(a.getOrDefault("currentTier","PREF"));e.newTier=String.valueOf(a.getOrDefault("newTier","PREF"));e.action=e.currentTier.equals(e.newTier)?"NO_CHANGE":(e.currentTier.equals("GOLD")&&e.newTier.equals("PLAT")?"UPTIER":"UPDATE"); repo.save(e); return Map.of("processingId",e.processingId,"status","ENROLLED","action",e.action,"newTier",e.newTier);}
 @GetMapping("/{processingId}") public Object get(@PathVariable String processingId){return repo.findByProcessingId(processingId).orElseThrow();}
}
