package com.infosys.financial;
import jakarta.persistence.*; import java.time.OffsetDateTime;
@Entity @Table(name="enrollments") public class Enrollment {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(name="processing_id",unique=true,nullable=false) public String processingId;
 @Column(name="customer_id",nullable=false) public String customerId;
 @Column(name="account_id",nullable=false) public String accountId;
 @Column(name="current_tier") public String currentTier;
 @Column(name="new_tier",nullable=false) public String newTier;
 @Column(nullable=false) public String action;
 @Column(name="created_at") public OffsetDateTime createdAt=OffsetDateTime.now();
}
