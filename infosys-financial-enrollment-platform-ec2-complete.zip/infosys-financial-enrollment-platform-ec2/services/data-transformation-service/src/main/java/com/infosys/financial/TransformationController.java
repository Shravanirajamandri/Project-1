package com.infosys.financial;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/transform") public class TransformationController { @PostMapping public Map<String,Object> endpoint(@RequestBody Map<String,Object> a){public Map<String,Object> transform(@RequestBody Map<String,Object> a){String t=String.valueOf(a.getOrDefault("newTier","PREF")); Map<String,String> codes=Map.of("SPWS","01","SPCS/PINN","02","PLAT","03","GOLD","04","PREF","05"); return Map.of("tier",t,"tierCode",codes.getOrDefault(t,"05"),"transformed",true); }} }
