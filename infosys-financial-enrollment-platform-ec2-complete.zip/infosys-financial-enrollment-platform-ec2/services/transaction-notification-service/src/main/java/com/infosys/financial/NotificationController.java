package com.infosys.financial;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/notify") public class NotificationController { @PostMapping public Map<String,Object> endpoint(@RequestBody Map<String,Object> a){public Map<String,Object> notify(@RequestBody Map<String,Object> a){return Map.of("status","SENT","targetSystem","Transaction Processing System","processingId",String.valueOf(a.getOrDefault("processingId","N/A")));}} }
